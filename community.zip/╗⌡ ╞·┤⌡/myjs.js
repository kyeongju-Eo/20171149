//메인페이지 검색 주의문
function searchbutton(){
    alert("현재 검색 기능은 사용하실 수 없습니다.").innHtml;
}

//아티클 하이퍼링크
function thishyper(){
    alert("아직 페이지가 구현되지 않았습니다.");
    //location.href = "/index.html"; 추후 페이지 작성 후 변경 요망
}

function content(){
    alert("아직 구현되지 않았습니다.");
    //location.href = "/index.html"; 추후 페이지 작성 후 변경 요망
}
